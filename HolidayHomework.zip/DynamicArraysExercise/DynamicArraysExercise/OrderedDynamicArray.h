#pragma once
#include <assert.h>

template<typename T>
class OrderedDynamicArray
{
public:
	OrderedDynamicArray(int size) : m_array(NULL), m_maxSize(0), m_numElements(0)
	{
		//Will be used to keep track of if the array needs to be increased
		m_maxSize = size;
		//Will be used both to keep track of how many elements there are as well as the effective size of the array
		m_numElements = 0;
		//Dynamically allocate m_array to the heap
		m_array = new T[m_maxSize];
	}

	~OrderedDynamicArray()
	{
		//if array is not NULL
		if (m_array != NULL) {
			//Invalidate and destroy the array
			m_array = nullptr;
			delete[] m_array;
		}
	}

	void Resize()
	{
		//Check that array exists
		assert(m_array != NULL);

		//Increase m_maxSize
		m_maxSize += 5;

		//Create a new temporary array of the new m_maxSize
		T* temp = new T[m_maxSize];

		//Copy original data into the temp
		memcpy(temp, m_array, sizeof(T) * m_numElements);

		//Delete the old array
		m_array = nullptr;
		delete[] m_array;

		//Recreate m_array with size m_maxSize
		m_array = new T[m_maxSize];

		//Copy data from the temp into the new m_array
		memcpy(m_array, temp, sizeof(T) * m_numElements);

		//Delete the temp array
		temp = nullptr;
		delete[] temp;
	}

	void Push(T value)
	{
		//Check the array exists
		assert(m_array != NULL);

		//If the array's capacity has been reached
		if (m_numElements >= m_maxSize) {
			Resize();
		}

		//iterate backward through the array from m_nunElements to 0
		for (int i = m_numElements; i >= 0; --i)
		{
			//If m_array[i - 1] is greater than or equal to value
			if (m_array[i - 1] >= value)
			{
				//set the current index to be the previous index
				m_array[i] = m_array[i - 1];

				//set the previous index to be value
				m_array[i - 1] = value;
			}
			//If m_array[i - 1] is smaller than value
			else if (m_array[i - 1] < value)
			{
				//set the current index to value and break from the for loop
				m_array[i] = value;
				break;
			}
		}
		//increment m_numElements
		++m_numElements;
	}

	void Pop()
	{
		//Check array exists
		assert(m_array != NULL);

		//If there are still elements in the array
		if (m_numElements > 0) {
			//decrement m_numElements
			--m_numElements;
		}
	}

	void Remove(int index)
	{
		//Check array exists and that the index is within the boundaries of the array
		assert(m_array != NULL && index <= m_maxSize);

		//iterare through the array from index to m_numElements
		for (int i = index; i < m_numElements; ++i) {
			//if we aren't at the last index
			if (i < m_maxSize) {
				//Overwrite the current index with the next
				m_array[i] = m_array[i + 1];
			}
			else {
				//Set current index to NULL
				m_array[i] = NULL;
			}
		}
		//decrement m_numElements
		--m_numElements;
	}

	void Clear()
	{
		//Set m_nunElements to 0, effectively deleting all data in the array
		m_numElements = 0;
	}

	virtual T& operator [] (const int& index)
	{
		//Check array exists and that the requested index is within the boundaries of the array
		assert(m_array != NULL && index <= m_numElements);

		//Return the value of the requested index
		return m_array[index];
	}

	int BinarySearch(T toFind)
	{
		//set max to m_numElements - 1 to account for 0 indexing
		int max = m_numElements - 1;
		int min = 0;

		//While we haven't checked every relevant piece of the array
		while (max >= min) {
			int middle = (min + max) / 2;

			//If toFind has been found
			if (m_array[middle] == toFind) {
				//Return the index it was found in
				return middle;
			}

			//If toFind is greater than the middle
			if (toFind > m_array[middle]) {
				//ignore 1st half
				min = middle + 1;
			}

			//If toFind is smaller than the middle
			if (toFind < m_array[middle]) {
				//ignore 2nd half
				max = middle - 1;
			}
		}
	}

private:
	T* m_array;
	int m_numElements;
	int m_maxSize;
};


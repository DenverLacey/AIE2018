#pragma once
#include "Iterator.h"
#include <assert.h>

template<class T>
class LinkedList
{
public:

	LinkedList() : m_elements(0)
	{
		m_first = nullptr;
		m_last = nullptr;
	}

	LinkedList(int startingElements) : m_elements(startingElements)
	{
		for (int i = 0; i < m_elements; ++i) {
			ListNode<T>* node = new ListNode<T>();

			if (i != 0) {
				m_first->prev = node;
				node->next = m_first;
			}

			m_first = node;
		}
	}

	~LinkedList()
	{
		while (m_first != nullptr) {
			auto* temp = m_first->next;
			delete m_first;
			m_first = temp;
		}
	}

	void PushFront(T value)
	{
		//Create new node
		ListNode<T>* N = new ListNode<T>();

		//Check whether this is the first new node
		if (m_first == nullptr) {
			//if so, have m_first and m_last point to this node
			m_first = N;
			m_last = N;
		}
		//If not so...
		else {
			//Set next to point to the first node which will soon be replaced
			N->next = m_first;

			//Set prev to nullptr as there are no nodes before this one
			N->prev = nullptr;

			//set the old first node's prev to the new first node
			m_first->prev = N;

			//set new first node to be m_first
			m_first = N;
		}
		N->value = value;
		++m_elements;
	}

	void PopFront()
	{
		ListNode<T>* N = m_first;

		if (m_first->next != NULL) {
			m_first->next->prev = m_first->prev;
		}

		m_first = m_first->next;

		--m_elements;
		delete N;
	}

	void PushBack(T value)
	{
		ListNode<T>* N = new ListNode<T>();
		if (m_first == nullptr) {
			m_first = N;
			m_last = N;
		}
		else {
			N->next = nullptr;
			N->prev = m_last;
			m_last->next = N;
			m_last = N;
		}
		N->value = value;
		++m_elements;
	}

	void PopBack()
	{
		ListNode<T>* N = m_last;

		if (m_last->prev != NULL) {
			m_last->prev->next = m_last->next;
		}

		m_last = m_last->prev;

		--m_elements;
		delete N;
	}

	void Remove(T value)
	{
		ListNode<T>* N = m_first;
		while (N != NULL) {
			ListNode<T>* temp = N->next;

			//if we've found a match
			if (N->value == value) {
				//cut ties with that node
				//If not the first node
				if (N->prev != NULL) {
					N->prev->next = N->next;
				}
				//if not the last node
				if (N->next != NULL) {
					N->next->prev = N->prev;
				}
				//if the first node
				if (N == m_first) {
					m_first = N->next;
				}
				//if the last node
				if (N == m_last) {
					m_last = N->prev;
				}
				--m_elements;
			}
			N = temp;
		}
	}

	void Insert(int node, int value)
	{
		//Check list exists
		assert(m_first != NULL);

		//If we aren't trying to access a node outside of the List
		if (node <= m_elements) {
			//Initialise the iterator
			Iterator<T>* itr = new Iterator<T>(m_first);

			//use iterator to find the current node
			for (int i = 0; i < node; ++i) {
				itr->m_node = itr->m_node->next;
			}

			//Create new node
			ListNode<T>* N = new ListNode<T>();
			//Set Value, next and prev
			N->value = value;
			N->next = nullptr;
			N->prev = nullptr;

			//Set N->next to itr->m_node
			N->next = itr->m_node;
			//Set N->prev to itr->m_node->prev
			if (itr->m_node->prev != NULL) {
				N->prev = itr->m_node->prev;
			}

			//Set m_node->prev->next to N
			if (itr->m_node->prev != NULL) {
				itr->m_node->prev->next = N;
			}

			//Set m_node->prev to N
			if (itr->m_node->prev != NULL) {
				itr->m_node->prev = N;
			}

			//increment m_elements
			++m_elements;
		}
	}

	void Erase(int node)
	{
		//Check list exists
		assert(m_first != NULL);
		if (node <= m_elements) {
			//Initialise Iterator
			Iterator<T>* itr = new Iterator<T>(m_first);
			//use iterator to find node
			for (int i = 0; i < node; ++i) {
				itr->m_node = itr->m_node->next;
			}

			//Create alias for itr->m_node
			ListNode<T>* N = itr->m_node;

			//Check that m_node->prev exists
			if (itr->m_node->prev != NULL) {
				//Cut out m_node from the list
				itr->m_node->prev->next = itr->m_node->next;
			}

			//Check that m_node->next exists
			if (itr->m_node->next != NULL) {
				//Cut out m_node from the list
				itr->m_node->next->prev = itr->m_node->prev;
			}

			--m_elements;
			delete N;
		}
	}

	int Count() { return m_elements; }

	bool Empty()
	{
		if (m_first == NULL) {
			return true;
		}
		else {
			return false;
		}
	}

	T First()
	{
		assert(m_elements > 0);
		return m_first->value;
	}

	T Last()
	{
		assert(m_elements > 0);
		return m_last->value;
	}

	ListNode<T>* Begin() { return m_first; }

	ListNode<T>* End() { return m_last->next; }

	void Print()
	{
		//Create new 
		ListNode<T>* N = m_first;
		while (N != NULL) {
			ListNode<T>* temp = N->next;

			std::cout << "[" << N->value << "] ";

			N = temp;
		}
		std::cout << std::endl;
	}

private:
	ListNode<T>* m_first;
	ListNode<T>* m_last;
	int m_elements;
};
#include <iostream>
#include "LinkedList.h"

using std::cout;
using std::cin;
using std::endl;

int main()
{
	LinkedList<int> list;

	list.PushFront(1);
	list.PushFront(2);
	list.PushFront(3);

	cout << "Before Pop:" << endl;
	list.Print();

	list.PopFront();
	list.PopBack();

	cout << "After Pop:" << endl;
	list.Print();

	list.PopFront();

	list.PushBack(1);
	list.PushBack(2);
	list.PushBack(3);
	list.PushBack(4);
	list.PushBack(4);

	cout << "Push Back:" << endl;
	list.Print();

	list.Remove(4);

	cout << "After Remove(4):" << endl;
	list.Print();

	list.PushBack(4);
	list.PushBack(5);
	list.PushBack(6);

	cout << "Insert: 6 at node 3" << endl;
	list.Insert(3, 6);
	list.Print();

	cout << "Erase Node 3" << endl;
	list.Erase(3);
	list.Print();

	cout << endl;
	cout << "Begin: " << list.Begin() << endl;
	cout << "End: " << list.End() << endl;
	cout << "Number of elements: " << list.Count() << endl;
	cout << "First Element: " << list.First() << endl;
	cout << "Last Element: " << list.Last() << endl;
	cout << "Empty List: " << list.Empty() << endl;

	cout << "Press 'Enter' to exit the program.";
	cin.get();
	return 0;
}
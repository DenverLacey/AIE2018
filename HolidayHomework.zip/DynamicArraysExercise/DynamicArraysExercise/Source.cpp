#include <iostream>
#include "DynamicArray.h"
#include "OrderedDynamicArray.h"

int main()
{
	//---------------UnorderedDynamicArray-----------//
	DynamicArray<int> uArray(5);

	uArray.Push(5);
	uArray.Push(7);
	uArray.Push(9);
	uArray.Push(3);
	uArray.Push(2);
	uArray.Push(1);
	uArray.Push(4);
	uArray.Push(6);
	uArray.Push(8);

	std::cout << "Initial Push:" << std::endl;
	for (int i = 0; i < 9; ++i) {
		std::cout << uArray[i] << std::endl;
	}

	std::cout << "Pop:" << std::endl;
	uArray.Pop();
	//Print Array
	for (int i = 0; i < 8; ++i) {
		std::cout << uArray[i] << std::endl;
	}

	std::cout << "Remove:" << std::endl;
	uArray.Remove(3);
	//Print Array
	for (int i = 0; i < 7; ++i) {
		std::cout << uArray[i] << std::endl;
	}

	std::cout << "Sort:" << std::endl;
	uArray.Sort();
	//Print Array
	for (int i = 0; i < 7; ++i) {
		std::cout << uArray[i] << std::endl;
	}

	//-----------------------------------------------//
	std::cout << std::endl << std::endl;
	//---------------OrderedDynamicArray-------------//
	OrderedDynamicArray<char> oArray(3);
	oArray.Push('a');
	oArray.Push('c');
	oArray.Push('b');
	oArray.Push('d');
	oArray.Push('e');
	//Print Array
	for (int i = 0; i < 5; ++i) {
		std::cout << oArray[i] << std::endl; //1 3 4 5 9
	}

	std::cout << "Binary Search:" << std::endl;
	std::cout << oArray.BinarySearch('c') << std::endl;

	//-----------------------------------------------//
	std::cout << "Press 'Enter' to exit the program.";
	std::cin.get();
	return 0;
}  
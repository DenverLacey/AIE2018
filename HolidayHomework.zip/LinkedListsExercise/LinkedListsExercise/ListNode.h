#pragma once
template<class T>
class ListNode
{
public:
	T value;
	ListNode* next;
	ListNode* prev;
};


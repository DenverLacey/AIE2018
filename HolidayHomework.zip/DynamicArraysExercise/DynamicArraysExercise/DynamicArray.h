#pragma once
#include <assert.h>

template<typename T>
class DynamicArray
{
public:
	DynamicArray(int size) : m_array(NULL), m_maxSize(0), m_numElements(0)
	{
		//Will be used to keep track of if the array needs to be increased
		m_maxSize = size;
		//Will be used both to keep track of how many elements there are as well as the effective size of the array
		m_numElements = 0;
		//Dynamically allocate m_array to the heap
		m_array = new T[m_maxSize];
	}

	~DynamicArray() 
	{
		//if array is not NULL
		if (m_array != NULL) {
			//Invalidate and destroy the array
			m_array = nullptr;
			delete[] m_array;
		}
	}

	void Push(T value)
	{
		//Check array exists
		assert(m_array != NULL);

		//If the array's capacity has been reached
		if (m_numElements >= m_maxSize) {
			Resize();
		}

		//Add value to the end of the array
		m_array[m_numElements] = value;

		//Increment m_nunElements
		++m_numElements;
	}

	void Pop()
	{
		//check array exists
		assert(m_array != NULL);

		//If there are still elements in the array
		if (m_numElements > 0) {

			//decrement m_numElements
			--m_numElements;
		}
	}
	
	void Insert(int index, T value)
	{
		//check array exists
		assert(m_array != NULL);

		//If index is greater than the size of the array
		if (index >= m_maxSize) {
			return;
		}
		//If num of elements > size of the array
		if (m_numElements >= m_maxSize) {
			//Resize the array to fit the new element
			Resize();
		}
		//Iterate backward through the array from m_nunElements to index
		for (int i = m_numElements; i < index; --i) {
			//shift elements by one slot to the right
			m_array[i] = m_array[i - 1];
		}

		//Add value to the array at the index specified
		m_array[index] = value;

		//increment m_nunElements
		++m_numElements;
	}

	void Remove(int index)
	{
		//Check array exists and that the index is within the boundaries of the array
		assert(m_array != NULL && index <= m_maxSize);
		
		//iterare through the array from index to m_numElements
		for (int i = index; i < m_numElements; ++i) {

			//if we aren't at the last index
			if (i < m_maxSize) {
				//Overwrite the current index with the next
				m_array[i] = m_array[i + 1];
			}
			else {
				//Set current index to NULL
				m_array[i] = NULL;
			}
		}
		//Decrement m_nunElements
		--m_numElements;
	}

	void Resize()
	{
		//Check that array exists
		assert(m_array != NULL);

		//Increase m_maxSize
		m_maxSize += 5;

		//Create a new temporary array of the new m_maxSize
		T* temp = new T[m_maxSize];

		//Copy original data into the temp
		memcpy(temp, m_array, sizeof(T) * m_numElements);

		//Delete the old array
		delete[] m_array;
		m_array = nullptr;

		//Recreate m_array with size m_maxSize
		m_array = new T[m_maxSize];

		//Copy data from the temp into the new m_array
		memcpy(m_array, temp, sizeof(T) * m_numElements);

		//Delete the temp array
		delete[] temp;
		temp = nullptr;
	}

	void Clear()
	{
		//Set m_nunElements to 0, effectively deleting all data in the array
		m_numElements = 0;
	}

	void Sort()
	{
		//iterate through the array from index 1 to m_nunElements
		for (int i = 1; i < m_numElements; ++i) {
			//Set key
			int key = m_array[i];
			//Set j to be the index which preceeds index i
			int j = i - 1;

			//Shift the key value backward through the array until its been swapped into the correct index
			while (j >= 0 && m_array[j] > key) {
				//Swap
				m_array[j + 1] = m_array[j];
				m_array[j] = key;

				//decrement j
				--j;
			}
		}
	}

	T& operator [] (const int& index)
	{
		//Check array exists and that the requested index is within the boundaries of the array
		assert(m_array != NULL && index <= m_numElements);

		//Return the value of the requested index
		return m_array[index];
	}


private:
	T* m_array;
	int m_maxSize;
	int m_numElements;
};

